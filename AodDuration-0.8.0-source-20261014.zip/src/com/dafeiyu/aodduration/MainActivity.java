package com.dafeiyu.aodduration;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.app.AlertDialog;
import android.graphics.Color;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/** Minimal dependency-free settings screen. */
public final class MainActivity extends Activity {
    private CheckBox enabled;
    private EditText panoramicValue;
    private EditText classicValue;
    private Spinner panoramicUnit;
    private Spinner classicUnit;
    private TextView status;
    private static final String AUTHOR = "我真的不姓峰_";

    private static int parse(EditText editText, int fallback) {
        try {
            return Integer.parseInt(editText.getText().toString().trim());
        } catch (Throwable ignored) {
            return fallback;
        }
    }

    private static int toSeconds(EditText value, Spinner unit, int fallback) {
        int number = parse(value, fallback);
        if (unit.getSelectedItemPosition() == 1) {
            if (number > ConfigProvider.MAX_SECONDS / 60) {
                return ConfigProvider.MAX_SECONDS;
            }
            number *= 60;
        }
        if (number < ConfigProvider.MIN_SECONDS || number > ConfigProvider.MAX_SECONDS) {
            return fallback;
        }
        return number;
    }

    private static void setDuration(EditText value, Spinner unit, int seconds) {
        if (seconds >= 60 && seconds % 60 == 0) {
            value.setText(String.valueOf(seconds / 60));
            unit.setSelection(1);
        } else {
            value.setText(String.valueOf(seconds));
            unit.setSelection(0);
        }
    }

    private LinearLayout row(String label, View input, View unit) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView text = new TextView(this);
        text.setText(label);
        text.setTextSize(16);
        row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(unit, new LinearLayout.LayoutParams(0, -2, 0.8f));
        return row;
    }

    private Spinner unitSpinner() {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new String[]{"秒", "分钟"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private EditText numberEdit() {
        EditText edit = new EditText(this);
        edit.setInputType(InputType.TYPE_CLASS_NUMBER);
        edit.setSingleLine(true);
        return edit;
    }

    private void requestStoragePermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT < 23) return;
        try {
            java.lang.reflect.Method method = Activity.class.getMethod(
                    "requestPermissions", String[].class, Integer.TYPE);
            method.invoke(this, new Object[]{new String[]{
                    "android.permission.READ_EXTERNAL_STORAGE",
                    "android.permission.WRITE_EXTERNAL_STORAGE"}, 1001});
        } catch (Throwable ignored) {
            // The app-private Provider path remains usable without storage access.
        }
    }

    private void showSponsorDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(36, 24, 36, 12);
        TextView note = new TextView(this);
        note.setText("AOD 时长控制\n作者：" + AUTHOR + "\n\n本项目免费使用，赞助完全自愿，不赞助不影响任何功能。\n\n感谢你的支持 🙏");
        note.setTextSize(16);
        box.addView(note, new LinearLayout.LayoutParams(-1, -2));
        ImageView qr = new ImageView(this);
        qr.setAdjustViewBounds(true);
        qr.setPadding(12, 18, 12, 8);
        int qrId = getResources().getIdentifier("wechat_sponsor_qr", "drawable", getPackageName());
        if (qrId != 0) qr.setImageResource(qrId);
        box.addView(qr, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("支持作者").setView(box)
                .setPositiveButton("关闭", null).show();
    }

    private void showAboutDialog() {
        new AlertDialog.Builder(this).setTitle("关于 AOD 时长控制")
                .setMessage("作者：" + AUTHOR + "\n\n"
                        + "免费开源项目。未经作者授权，不得去除署名、冒名发布、以作者名义收费或制作误导性衍生版本。\n\n"
                        + "本项目采用 Apache License 2.0：允许按许可证修改和再发布，但必须保留版权、许可证和 NOTICE。\n\n"
                        + "风险提示：本模块针对特定 ColorOS/SystemUI 版本，刷入前请确认兼容性并保留回退方案。")
                .setPositiveButton("知道了", null).show();
    }

    private void load() {
        ConfigProvider.Config config = ConfigProvider.readConfig(this);
        enabled.setChecked(config.enabled);
        setDuration(panoramicValue, panoramicUnit, config.panoramicSeconds);
        setDuration(classicValue, classicUnit, config.classicSeconds);
        status.setText("配置文件：/storage/emulated/0/Android/media/com.dafeiyu.aodduration/aod-duration.conf\n"
                + "有效范围：1 秒至 30 分钟；关闭后恢复系统默认 5 秒。\n"
                + "修改会在下一次 AOD 计时触发时读取。找不到目标类时模块自动跳过。\n"
                + "当前：全景 " + config.panoramicSeconds + " 秒，普通 "
                + config.classicSeconds + " 秒");
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 28, 32, 28);

        TextView title = new TextView(this);
        title.setText("ColorOS AOD 时长控制");
        title.setTextSize(22);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView explanation = new TextView(this);
        explanation.setText("只调整 AOD 的短时自动隐藏闹钟；低光、低电量、烧屏保护和其它传感器规则不被关闭。\n需要在 LSPosed 中同时勾选 SystemUI 和息屏（com.oplus.aod）作用域，然后重启 SystemUI。\n");
        explanation.setTextSize(14);
        root.addView(explanation, new LinearLayout.LayoutParams(-1, -2));
        TextView author = new TextView(this);
        author.setText("作者：我真的不姓峰_  ·  免费使用  ·  Apache License 2.0\n警告：未经授权不得去除署名、冒名发布、以作者名义收费或制作误导性版本。修改和再发布请遵守许可证并保留 NOTICE。\n");
        author.setTextSize(13);
        author.setTextColor(Color.DKGRAY);
        root.addView(author, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout infoButtons = new LinearLayout(this);
        infoButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button about = new Button(this);
        about.setText("作者与许可");
        Button sponsor = new Button(this);
        sponsor.setText("赞助作者（自愿）");
        infoButtons.addView(about, new LinearLayout.LayoutParams(0, -2, 1));
        infoButtons.addView(sponsor, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(infoButtons, new LinearLayout.LayoutParams(-1, -2));
        about.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showAboutDialog(); } });
        sponsor.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showSponsorDialog(); } });

        enabled = new CheckBox(this);
        enabled.setText("启用自定义时长");
        root.addView(enabled, new LinearLayout.LayoutParams(-1, -2));

        panoramicValue = numberEdit();
        panoramicUnit = unitSpinner();
        root.addView(row("全景 AOD：", panoramicValue, panoramicUnit),
                new LinearLayout.LayoutParams(-1, -2));

        classicValue = numberEdit();
        classicUnit = unitSpinner();
        root.addView(row("普通 AOD：", classicValue, classicUnit),
                new LinearLayout.LayoutParams(-1, -2));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button save = new Button(this);
        save.setText("保存");
        Button reset = new Button(this);
        reset.setText("恢复默认");
        Button reload = new Button(this);
        reload.setText("重新读取");
        buttons.addView(save, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(reset, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(reload, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(buttons, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setTextSize(13);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));
        requestStoragePermissionIfNeeded();
        setContentView(root);
        load();

        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                int panoramic = toSeconds(panoramicValue, panoramicUnit,
                        ConfigProvider.DEFAULT_SECONDS);
                int classic = toSeconds(classicValue, classicUnit,
                        ConfigProvider.DEFAULT_SECONDS);
                ConfigProvider.saveConfig(MainActivity.this, enabled.isChecked(), panoramic, classic);
                load();
                Toast.makeText(MainActivity.this, "已保存；下一次 AOD 计时生效", Toast.LENGTH_SHORT).show();
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                ConfigProvider.resetConfig(MainActivity.this);
                load();
                Toast.makeText(MainActivity.this, "已恢复系统默认 5 秒", Toast.LENGTH_SHORT).show();
            }
        });
        reload.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { load(); }
        });
    }
}
