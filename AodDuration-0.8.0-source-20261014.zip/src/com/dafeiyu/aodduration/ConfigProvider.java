package com.dafeiyu.aodduration;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Small, read-only-to-SystemUI configuration bridge. */
public final class ConfigProvider extends ContentProvider {
    public static final String AUTHORITY = "com.dafeiyu.aodduration.config";
    public static final int DEFAULT_SECONDS = 5;
    public static final int MIN_SECONDS = 1;
    public static final int MAX_SECONDS = 1800;
    private static final String PREFS = "aod_duration";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_PANORAMIC = "panoramic_seconds";
    private static final String KEY_CLASSIC = "classic_seconds";

    public static final class Config {
        public final boolean enabled;
        public final int panoramicSeconds;
        public final int classicSeconds;

        public Config(boolean enabled, int panoramicSeconds, int classicSeconds) {
            this.enabled = enabled;
            this.panoramicSeconds = clamp(panoramicSeconds);
            this.classicSeconds = clamp(classicSeconds);
        }
    }

    private static File externalFile() {
        return new File(Environment.getExternalStorageDirectory(),
                "Android/media/com.dafeiyu.aodduration/aod-duration.conf");
    }

    private static int clamp(int value) {
        if (value < MIN_SECONDS || value > MAX_SECONDS) {
            return DEFAULT_SECONDS;
        }
        return value;
    }

    private static int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value.trim());
        } catch (Throwable ignored) {
            return fallback;
        }
    }

    private static boolean parseBoolean(String value, boolean fallback) {
        String v = value == null ? "" : value.trim();
        if ("1".equals(v) || "true".equalsIgnoreCase(v) || "on".equalsIgnoreCase(v)) {
            return true;
        }
        if ("0".equals(v) || "false".equalsIgnoreCase(v) || "off".equalsIgnoreCase(v)) {
            return false;
        }
        return fallback;
    }

    private static Map<String, String> readExternal() {
        Map<String, String> values = new HashMap<>();
        File file = externalFile();
        if (!file.isFile() || !file.canRead()) {
            return values;
        }
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.length() == 0 || line.startsWith("#")) {
                    continue;
                }
                int equals = line.indexOf('=');
                if (equals <= 0) {
                    continue;
                }
                String key = line.substring(0, equals).trim();
                String value = line.substring(equals + 1).trim();
                values.put(key, value);
            }
        } catch (Throwable ignored) {
            // The hook must fail open if external storage is unavailable.
        }
        return values;
    }

    public static Config readConfig(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        boolean enabled = prefs.getBoolean(KEY_ENABLED, true);
        int panoramic = prefs.getInt(KEY_PANORAMIC, DEFAULT_SECONDS);
        int classic = prefs.getInt(KEY_CLASSIC, DEFAULT_SECONDS);

        Map<String, String> external = readExternal();
        if (external.containsKey(KEY_ENABLED)) {
            enabled = parseBoolean(external.get(KEY_ENABLED), enabled);
        }
        if (external.containsKey(KEY_PANORAMIC)) {
            panoramic = parseInt(external.get(KEY_PANORAMIC), panoramic);
        }
        if (external.containsKey(KEY_CLASSIC)) {
            classic = parseInt(external.get(KEY_CLASSIC), classic);
        }
        return new Config(enabled, panoramic, classic);
    }

    public static void saveConfig(Context context, boolean enabled, int panoramic, int classic) {
        panoramic = clamp(panoramic);
        classic = clamp(classic);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, enabled)
                .putInt(KEY_PANORAMIC, panoramic)
                .putInt(KEY_CLASSIC, classic)
                .apply();

        File file = externalFile();
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            //noinspection ResultOfMethodCallIgnored
            parent.mkdirs();
        }
        File temporary = new File(file.getPath() + ".tmp");
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(temporary), StandardCharsets.UTF_8))) {
            writer.println("# AOD Duration configuration; seconds, range 1..1800");
            writer.println("enabled=" + (enabled ? "1" : "0"));
            writer.println("panoramic_seconds=" + panoramic);
            writer.println("classic_seconds=" + classic);
        } catch (Throwable ignored) {
            return;
        }
        if (!temporary.renameTo(file)) {
            try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                    new FileOutputStream(file), StandardCharsets.UTF_8))) {
                writer.println("enabled=" + (enabled ? "1" : "0"));
                writer.println("panoramic_seconds=" + panoramic);
                writer.println("classic_seconds=" + classic);
            } catch (Throwable ignored) {
                // Internal preferences remain available.
            }
        }
    }

    public static void resetConfig(Context context) {
        saveConfig(context, true, DEFAULT_SECONDS, DEFAULT_SECONDS);
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        if ("get_config".equals(method)) {
            Config config = readConfig(getContext());
            Bundle result = new Bundle();
            result.putBoolean(KEY_ENABLED, config.enabled);
            result.putInt(KEY_PANORAMIC, config.panoramicSeconds);
            result.putInt(KEY_CLASSIC, config.classicSeconds);
            return result;
        }
        return super.call(method, arg, extras);
    }

    @Override public String getType(Uri uri) { return null; }
    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection,
                                String[] selectionArgs) { return 0; }
}
