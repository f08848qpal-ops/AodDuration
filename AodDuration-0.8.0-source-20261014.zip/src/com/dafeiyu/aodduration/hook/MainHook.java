package com.dafeiyu.aodduration.hook;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.os.Bundle;
import android.os.SystemClock;

import java.util.concurrent.atomic.AtomicLong;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Narrow, fail-open hook for ColorOS 16 AOD's short hide timeout.
 *
 * The timer owner is SystemUI. The module declares both SystemUI and AOD
 * scopes because ColorOS AOD features are split across the two packages, but
 * the actual HIDE_TIME scheduling is in SystemUI.
 */
public final class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "AodDuration";
    private static final String SYSTEM_UI = "com.android.systemui";
    private static final String OPLUS_AOD = "com.oplus.aod";
    private static final String UPDATE_MANAGER =
            "com.oplus.systemui.aod.aodclock.off.AodUpdateManager";
    private static final String WAKE_CONTROLLER =
            "com.oplus.systemui.aod.display.OplusWakeUpController";
    private static final String AOD_DATA =
            "com.oplus.systemui.aod.aodclock.constant.AodData";
    private static final String AOD_DISPLAY_UTIL =
            "com.oplus.systemui.aod.display.AODDisplayUtil";
    private static final String CONFIG_AUTHORITY = "com.dafeiyu.aodduration.config";
    private static final long DEFAULT_DELAY = 5000L;
    private static final long MIN_DELAY = 1000L;
    private static final long MAX_DELAY = 1800000L;
    private static final AtomicLong LAST_LOG = new AtomicLong(0L);

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (OPLUS_AOD.equals(lpparam.packageName)) {
            // Scope is intentional: AOD owns the settings/UI, while SystemUI
            // owns the HIDE_TIME alarm. Do not hook arbitrary AOD UI timers.
            log("attached to com.oplus.aod; timer hook is in SystemUI");
            return;
        }
        if (!SYSTEM_UI.equals(lpparam.packageName)) {
            return;
        }
        try {
            final Class<?> managerClass = XposedHelpers.findClass(
                    UPDATE_MANAGER, lpparam.classLoader);
            XposedHelpers.findAndHookMethod(managerClass, "setHideAlarm",
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            replaceClockLayoutAlarm(param, lpparam.classLoader);
                        }
                    });
            log("hooked " + UPDATE_MANAGER + ".setHideAlarm()");
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": AOD manager hook unavailable; fail-open: " + error);
        }
        try {
            final Class<?> wakeClass = XposedHelpers.findClass(
                    WAKE_CONTROLLER, lpparam.classLoader);
            XposedHelpers.findAndHookMethod(wakeClass, "setHideAlarm",
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            replaceWakeControllerAlarm(param, lpparam.classLoader);
                        }
                    });
            log("hooked " + WAKE_CONTROLLER + ".setHideAlarm()");
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": wake controller hook unavailable; fail-open: " + error);
        }
    }

    private static void replaceClockLayoutAlarm(
            XC_MethodHook.MethodHookParam param, ClassLoader loader) {
        try {
            if (callerKind() != CallerKind.CLOCK_LAYOUT) {
                return;
            }
            Object manager = param.thisObject;
            Context context = getContext(manager);
            if (context == null || !isAodSwitchEnabled(manager)) {
                return;
            }
            AodMode mode = getAodMode(context, loader);
            if (mode == AodMode.NONE) {
                return;
            }
            Config config = readConfig(context);
            if (!config.enabled) {
                return;
            }
            long delay = delayFor(mode, config);
            if (delay == DEFAULT_DELAY || !scheduleHideAlarmLikeStock(manager, delay)) {
                return;
            }
            param.setResult(null);
            logRateLimited("clock " + mode + " HIDE_TIME delay=" + delay + "ms");
        } catch (Throwable error) {
            logRateLimited("clock hook error; stock alarm retained: " + error);
        }
    }

    /**
     * On full-day panoramic AOD, AodClockLayout may not enter its energy-saving
     * branch. The wake controller then becomes the real short-display path.
     * SensorManager calls AodUpdateManager directly and are intentionally not
     * routed here, so low-light/orientation protection is left unchanged.
     */
    private static void replaceWakeControllerAlarm(
            XC_MethodHook.MethodHookParam param, ClassLoader loader) {
        try {
            Object wakeController = param.thisObject;
            Context context = getContext(wakeController);
            if (context == null) {
                return;
            }
            AodMode mode = getAodMode(context, loader);
            if (mode == AodMode.NONE) {
                return;
            }
            Config config = readConfig(context);
            if (!config.enabled) {
                return;
            }
            long delay = delayFor(mode, config);
            logRateLimited("wake path seen: " + mode + ", configured=" + delay + "ms");
            if (delay == DEFAULT_DELAY) {
                return;
            }
            Object manager = getUpdateManager(context, loader);
            if (manager == null || !scheduleHideAlarmLikeStock(manager, delay)) {
                return;
            }
            param.setResult(null);
            logRateLimited("wake " + mode + " HIDE_TIME delay=" + delay + "ms");
        } catch (Throwable error) {
            logRateLimited("wake hook error; stock alarm retained: " + error);
        }
    }

    private enum CallerKind { WAKE_UP_CONTROLLER, SENSOR, CLOCK_LAYOUT, OTHER }
    private enum AodMode { PANORAMIC, CLASSIC, NONE }

    private static CallerKind callerKind() {
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        boolean wake = false;
        boolean sensor = false;
        boolean clock = false;
        for (StackTraceElement element : stack) {
            String name = element.getClassName();
            if (name.contains("AodSensorManager")) {
                sensor = true;
            } else if (name.contains("OplusWakeUpController")) {
                wake = true;
            } else if (name.contains("AodClockLayout")) {
                clock = true;
            }
        }
        if (sensor) return CallerKind.SENSOR;
        if (wake) return CallerKind.WAKE_UP_CONTROLLER;
        return clock ? CallerKind.CLOCK_LAYOUT : CallerKind.OTHER;
    }

    private static Context getContext(Object object) {
        try {
            for (String name : new String[]{"mContext", "context"}) {
                try {
                    Object value = XposedHelpers.getObjectField(object, name);
                    if (value instanceof Context) return (Context) value;
                } catch (Throwable ignored) {
                    // Try the next field name.
                }
            }
        } catch (Throwable ignored) {
            // Fail open.
        }
        return null;
    }

    private static boolean isAodSwitchEnabled(Object manager) {
        try {
            Object data = XposedHelpers.getObjectField(manager, "mAodData");
            Object options = XposedHelpers.getObjectField(data, "mAodOptionsMgr");
            Object result = XposedHelpers.callMethod(options,
                    "isCurrentAodSwitchEnable");
            return result instanceof Boolean && (Boolean) result;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static Object getUpdateManager(Context context, ClassLoader loader) {
        try {
            Class<?> clazz = XposedHelpers.findClass(UPDATE_MANAGER, loader);
            return XposedHelpers.callStaticMethod(clazz, "getInstance",
                    new Class<?>[]{Context.class}, context);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static AodMode getAodMode(Context context, ClassLoader loader) {
        try {
            Class<?> dataClass = XposedHelpers.findClass(AOD_DATA, loader);
            Object data = XposedHelpers.callStaticMethod(dataClass, "getInstance",
                    new Class<?>[]{Context.class}, context);
            Object panoramic = XposedHelpers.callMethod(data, "isPanoramicAod");
            if (panoramic instanceof Boolean && (Boolean) panoramic) {
                return AodMode.PANORAMIC;
            }
        } catch (Throwable ignored) {
            // Use the process-type fallback below.
        }
        try {
            Class<?> utilClass = XposedHelpers.findClass(AOD_DISPLAY_UTIL, loader);
            Object util = XposedHelpers.callStaticMethod(utilClass, "getInstance",
                    new Class<?>[]{Context.class}, context);
            Object classic = XposedHelpers.callMethod(util, "isClassicProcessType");
            if (classic instanceof Boolean && (Boolean) classic) {
                return AodMode.CLASSIC;
            }
        } catch (Throwable ignored) {
            // Keep the conservative NONE result.
        }
        return AodMode.NONE;
    }

    private static long delayFor(AodMode mode, Config config) {
        int seconds = mode == AodMode.PANORAMIC
                ? config.panoramicSeconds : config.classicSeconds;
        return clampDelay(seconds * 1000L);
    }

    private static final class Config {
        final boolean enabled;
        final int panoramicSeconds;
        final int classicSeconds;
        Config(boolean enabled, int panoramicSeconds, int classicSeconds) {
            this.enabled = enabled;
            this.panoramicSeconds = panoramicSeconds;
            this.classicSeconds = classicSeconds;
        }
    }

    private static Config readConfig(Context context) {
        boolean enabled = true;
        int panoramic = 5;
        int classic = 5;
        boolean providerRead = false;
        try {
            ContentResolver resolver = context.getContentResolver();
            Bundle result = resolver.call(
                    android.net.Uri.parse("content://" + CONFIG_AUTHORITY),
                    "get_config", null, null);
            if (result != null) {
                enabled = result.getBoolean("enabled", true);
                panoramic = result.getInt("panoramic_seconds", 5);
                classic = result.getInt("classic_seconds", 5);
                providerRead = true;
            }
        } catch (Throwable error) {
            logRateLimited("config provider failed: " + error.getClass().getSimpleName());
        }
        if (!providerRead) {
            File file = new File("/sdcard/Android/media/com.dafeiyu.aodduration/aod-duration.conf");
            if (file.isFile() && file.canRead()) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        new FileInputStream(file), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        line = line.trim();
                        int split = line.indexOf('=');
                        if (split <= 0) continue;
                        String key = line.substring(0, split).trim();
                        String value = line.substring(split + 1).trim();
                        if ("enabled".equals(key)) {
                            enabled = "1".equals(value) || "true".equalsIgnoreCase(value);
                        } else if ("panoramic_seconds".equals(key)) {
                            try { panoramic = Integer.parseInt(value); } catch (Throwable ignored) { }
                        } else if ("classic_seconds".equals(key)) {
                            try { classic = Integer.parseInt(value); } catch (Throwable ignored) { }
                        }
                    }
                    logRateLimited("using external config fallback");
                } catch (Throwable error) {
                    logRateLimited("external config failed: " + error.getClass().getSimpleName());
                }
            }
        }
        if (panoramic < 1 || panoramic > 1800) panoramic = 5;
        if (classic < 1 || classic > 1800) classic = 5;
        logRateLimited("config enabled=" + enabled + ", panoramic=" + panoramic
                + ", classic=" + classic + ", provider=" + providerRead);
        return new Config(enabled, panoramic, classic);
    }

    private static boolean scheduleHideAlarmLikeStock(Object manager, long delay) {
        try {
            boolean registered = XposedHelpers.getBooleanField(
                    manager, "mHasRegisterHideBroadcast");
            if (!registered) XposedHelpers.callMethod(manager, "registerHideBroadcast");
            AlarmManager alarmManager = (AlarmManager) XposedHelpers.getObjectField(
                    manager, "mAlarmManager");
            PendingIntent hideIntent = (PendingIntent) XposedHelpers.getObjectField(
                    manager, "mHideIntent");
            if (alarmManager == null || hideIntent == null) return false;
            alarmManager.cancel(hideIntent);
            java.lang.reflect.Method method = AlarmManager.class.getMethod(
                    "setExactAndAllowWhileIdle", int.class, long.class, PendingIntent.class);
            method.invoke(alarmManager, AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    SystemClock.elapsedRealtime() + delay, hideIntent);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static long clampDelay(long delay) {
        return delay < MIN_DELAY || delay > MAX_DELAY ? DEFAULT_DELAY : delay;
    }

    private static void log(String message) {
        XposedBridge.log(TAG + ": " + message);
    }

    private static void logRateLimited(String message) {
        long now = SystemClock.elapsedRealtime();
        long previous = LAST_LOG.get();
        if (now - previous > 5000L && LAST_LOG.compareAndSet(previous, now)) {
            XposedBridge.log(TAG + ": " + message);
        }
    }
}
