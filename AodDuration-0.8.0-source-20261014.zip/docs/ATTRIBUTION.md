# Attribution and author notice

Author: **我真的不姓峰_**

AodDuration is free to use. The project uses Apache License 2.0. You may modify and redistribute it only while complying with that license, preserving copyright/license/NOTICE, and without removing the author attribution, impersonating the author, charging users while claiming to be the author or official distributor, or distributing misleading builds.

The sponsorship QR image included in the app was provided by the author. Sponsorship is optional and never gates any feature.
