# Build

## GitHub Actions

Push the repository and run the `Build AodDuration` workflow. It produces an unsigned APK artifact. Sign it with your own key before distribution; never commit a private signing key.

## Local Gradle

```bash
./gradlew :app:assembleRelease
```

The Xposed API is compile-only and is not packaged into the APK. The repository intentionally excludes generated build output, SDK/tool jars and signing keys.

## Reference-device manual build

The original on-device development build used JDK 17/21, `aapt2`, R8/D8, `apksigner`, and a local Xposed API 82 jar. It is useful for reproducing the reference APK but is not required for the public Gradle build.
