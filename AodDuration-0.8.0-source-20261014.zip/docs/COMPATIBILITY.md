# Compatibility

## Verified reference environment

- Device: PLR110 / OP6117L1
- Android: 16
- ColorOS: PLR110_16.0.9.400(CN01)
- SystemUI: 16.99.12
- AOD: 16.003.0015

## Hooked classes

- `com.oplus.systemui.aod.aodclock.off.AodUpdateManager#setHideAlarm()`
- `com.oplus.systemui.aod.display.OplusWakeUpController#setHideAlarm()`
- runtime mode detection through `AodData#isPanoramicAod()` and `AODDisplayUtil#isClassicProcessType()`

## Safety boundaries

The module does not hook `AodSensorManager`, low-light hiding, burn-in counters, or the energy-saving hide callback. It fails open when a class/method is absent.

Other ROMs may rename classes, change the caller path, or move the timer. A successful APK install does not mean the hook is compatible; inspect LSPosed logs for `AodDuration:` lines.
