# AodDuration

一个针对 ColorOS AOD 的 LSPosed 模块：在不关闭低光、低电量、姿态和烧屏保护的前提下，为兼容设备提供可配置的短时息屏显示时长。

> 当前已在 PLR110 / OP6117L1、ColorOS `PLR110_16.0.9.400(CN01)`、SystemUI 16.99.12、AOD 16.003.0015 上验证。其他设备需要看 LSPosed 日志确认兼容性。

## 安装与作用域

在 LSPosed 中启用模块并勾选两个作用域：

- `com.android.systemui`（系统界面）
- `com.oplus.aod`（息屏）

然后重启 SystemUI 或重启手机。

## 配置

直接打开模块应用设置全景/普通 AOD 秒数或分钟数。可选手工配置文件：

```text
/storage/emulated/0/Android/media/com.dafeiyu.aodduration/aod-duration.conf
```

```ini
enabled=1
panoramic_seconds=15
classic_seconds=15
```

范围为 1～1800 秒。应用私有配置 Provider 是主通道；外部文件只作为可移植备用通道。

## Hook 边界

实际定时器位于 SystemUI 的 `AodUpdateManager.setHideAlarm()` 和 `OplusWakeUpController.setHideAlarm()`。模块只处理时钟布局/唤醒短显示路径，排除 `AodSensorManager`，不改低光、低电量、烧屏计数和节能隐藏逻辑。目标不存在时自动跳过。

## 日志诊断

过滤 LSPosed 日志：

```text
AodDuration
```

正常加载应看到：

```text
hooked com.oplus.systemui.aod.aodclock.off.AodUpdateManager.setHideAlarm()
hooked com.oplus.systemui.aod.display.OplusWakeUpController.setHideAlarm()
```

命中计时路径时还应看到 `configured=...ms` 或 `HIDE_TIME delay=...ms`。

## 回退

在 LSPosed 中禁用模块并重启 SystemUI。模块不替换系统 APK。

## 开源与隐私

本项目不包含设备私钥、用户配置或个人工作区。请使用自己的签名密钥发布 APK。

许可证见 [LICENSE](LICENSE)，兼容性说明见 [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md), [docs/ATTRIBUTION.md](docs/COMPATIBILITY.md)。

## Author and optional sponsorship

作者：**我真的不姓峰_**。

本项目免费使用。应用内的“赞助作者（自愿）”入口只展示作者提供的微信收款码；不赞助也可以使用全部功能。作者与许可说明见 [ATTRIBUTION](docs/ATTRIBUTION.md)。
