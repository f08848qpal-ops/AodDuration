# Changelog

## 0.8.0 — portable public-release baseline

- Removed the personal `大肥鱼Agent` storage path from source code.
- Canonical optional file path is now `Android/media/com.dafeiyu.aodduration/aod-duration.conf`.
- Added Gradle project files for public builds.
- Added explicit LSPosed scope metadata for `com.android.systemui` and `com.oplus.aod`.
- Kept the verified SystemUI timeout hooks and fail-open behavior.
- Added config fallback diagnostics for devices where the exported provider cannot be reached from SystemUI.

## 0.6.0

- Added external configuration fallback after diagnosing cross-process provider defaults on the reference device.

## 0.8.0 — author and optional sponsorship UI

- Added author attribution for `我真的不姓峰_`.
- Added an author/license warning that is consistent with Apache 2.0.
- Added an optional WeChat sponsorship dialog using the author-provided QR image.
- Sponsorship does not gate or unlock any feature.
- Added the portable QR asset and GitHub Actions build workflow.
